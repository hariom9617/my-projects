document.getElementById("setIncomeBtn").addEventListener("click", setIncome);
document.getElementById("addExpenseBtn").addEventListener("click", addExpense);

let income = 0;
let expenses = [];
let totalAmount = 0;

function setIncome() {
  income = parseFloat(document.getElementById("incomeInput").value);
  if (!income || income <= 0) {
    alert("Please enter a valid income.");
    return;
  }
  document.getElementById("incomeDisplay").innerText = `Income: ₹${income.toFixed(2)}`;
  updateBalance();
  updateChart();
}

function addExpense() {
  const name = document.getElementById("expenseName").value;
  const amount = parseFloat(document.getElementById("expenseAmount").value);
  const date = document.getElementById("expenseDate").value;

  if (!name || !amount || amount <= 0 || !date) {
    alert("Please enter valid expense details.");
    return;
  }

  expenses.push({ name, amount, date });
  totalAmount += amount;

  updateExpenseList();
  updateBalance();
  updateChart();

  document.getElementById("expenseName").value = "";
  document.getElementById("expenseAmount").value = "";
  document.getElementById("expenseDate").value = "";
}

function updateExpenseList() {
  const expensesList = document.getElementById("expenses");
  expensesList.innerHTML = "";

  expenses.forEach((expense, index) => {
    const li = document.createElement("li");
    li.innerHTML = `${expense.name} (₹${expense.amount.toFixed(2)}) on ${expense.date}
      <button onclick="deleteExpense(${index})">Delete</button>`;
    expensesList.appendChild(li);
  });
}

function updateBalance() {
  const balance = income - totalAmount;
  document.getElementById("total").innerText = `Total Expenses: ₹${totalAmount.toFixed(2)}`;
  document.getElementById("balance").innerText = `Remaining Balance: ₹${balance.toFixed(2)}`;
}

function deleteExpense(index) {
  totalAmount -= expenses[index].amount;
  expenses.splice(index, 1);
  updateExpenseList();
  updateBalance();
  updateChart();
}

const ctx = document.getElementById("expenseChart").getContext("2d");
let chart = new Chart(ctx, {
  type: "line",
  data: {
    labels: [],
    datasets: [
      {
        label: "₹ Amount",
        data: [],
        borderColor: "#007bff",
        backgroundColor: "rgba(0, 123, 255, 0.2)",
        fill: true,
        tension: 0.4,
      },
    ],
  },
  options: {
    responsive: true,
    scales: {
      x: {
        title: {
          display: true,
          text: "Date",
        },
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: "Amount (₹)",
        },
      },
    },
  },
});

function updateChart() {
  const dates = expenses.map(expense => expense.date);
  const amounts = expenses.map(expense => expense.amount);

  chart.data.labels = dates;
  chart.data.datasets[0].data = amounts;
  chart.update();
}
