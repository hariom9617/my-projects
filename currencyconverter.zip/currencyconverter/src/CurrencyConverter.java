import java.util.Scanner;

public class CurrencyConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char continueConversion = 'y'; // Initialize to 'y' to avoid the uninitialized variable error

        do {
            // Example conversion rates
            double inrToUsdRate = 0.012; // 1 INR to USD
            double inrToEurRate = 0.011; // 1 INR to EUR
            double inrToGbpRate = 0.0093; // 1 INR to GBP
            double inrToAudRate = 0.019; // 1 INR to AUD

            System.out.println("Welcome to Currency Converter");
            System.out.println("Select the conversion type:");
            System.out.println("1. INR to USD");
            System.out.println("2. INR to EUR");
            System.out.println("3. INR to GBP");
            System.out.println("4. INR to AUD");

            int choice = scanner.nextInt();

            if (choice < 1 || choice > 4) {
                System.out.println("Invalid choice! Please select a valid option.");
                continue;
            }

            System.out.print("Enter amount in INR: ");
            double inrAmount = scanner.nextDouble();

            double convertedAmount; // No need for redundant initialization
            switch (choice) {
                case 1:
                    convertedAmount = inrAmount * inrToUsdRate;
                    System.out.printf("Converted Amount: %.2f USD%n", convertedAmount);
                    break;
                case 2:
                    convertedAmount = inrAmount * inrToEurRate;
                    System.out.printf("Converted Amount: %.2f EUR%n", convertedAmount);
                    break;
                case 3:
                    convertedAmount = inrAmount * inrToGbpRate;
                    System.out.printf("Converted Amount: %.2f GBP%n", convertedAmount);
                    break;
                case 4:
                    convertedAmount = inrAmount * inrToAudRate;
                    System.out.printf("Converted Amount: %.2f AUD%n", convertedAmount);
                    break;
            }

            // Ask if the user wants to convert another currency
            System.out.print("Do you want to convert another currency? (y/n): ");
            continueConversion = scanner.next().charAt(0);

        } while (continueConversion == 'y' || continueConversion == 'Y');

        System.out.println("Thank you for using the Currency Converter. Goodbye!");
        scanner.close();
    }
}
